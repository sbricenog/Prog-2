
public class Ejercicios {

    
    public static void main(String[] args) {
        
        double valorPI = Math.PI;
        double raiz = Math.sqrt(25);
        double Hipotenusa = Math.hypot(15, 9);
        double Logaritmo = Math.log(4);
        int Nmayor = Math.max(4, 9);
        int Nmenor = Math.min(4, 9);
        double Potencia = Math.pow(5, 4);
        
        System.out.println(" El valor PI = "+valorPI);
        System.out.println(" La raiz = "+ raiz);
        System.out.println(" Hipotenusa = "+Hipotenusa);
        System.out.println("Logaritmo Natural = "+Logaritmo);
        System.out.println(" Número mayor = "+Nmayor);
        System.out.println(" Número menor = "+Nmenor);
        System.out.println(" Potencia = "+Potencia);
               
    }
    
}
